# Noum — Evidence Bundle v2 (supplemental)

## Read this first

This is a **supplement** to the v1 bundle
(`Noum-research-f441dd019-20260723-172245.zip`), not a replacement. v1 already
covered the five tabs, the mode picker + every mode setup, league, path,
Ask Noum idle, goal refresh, notification pre-prompt, and the weekly check-in.
This v2 bundle adds only the surfaces that were **missing** from v1 — the ones a
UX review would need to avoid the specific wrong conclusions the first Deep
Research report drew.

Same source commit as v1: `f441dd0191eb08f79ea159583878c1558f900df7` on
`ux-overhaul`, built with Xcode 26.3 / scheme `Noum-StoreKit` on iPhone 17 Pro
(iOS 26.5). All six capture tests passed.

## One honesty note on the working tree

The tree is **dirty by one test-only change**: `NoumUITests/ScreenshotTour.swift`
gains a single method, `testCaptureLiveCoachCall`, which drives **existing**
production UI-testing hooks (`UI_TESTING_FORCE_LIVE_COACH`,
`UI_TESTING_LIVE_FORCE_PLAIN_SCAFFOLD_CAPTION`) to reach the live call surface.
No production Swift was touched. Every captured screen reflects commit
`f441dd019` unmodified. The full diff is in `test-harness-addition.diff` (44
lines) so a reviewer can confirm it is test scaffolding, not a product change.

## What each capture proves — and which report claim it corrects

**L-01 / L-02 — the immersive live coach call (the DEFAULT coach surface).**
A full-screen push-to-talk call: pulsing orb, "Noum" title, a coach caption
("You want it straight. Give one 30-second update, state the recommendation
first, then stop."), and a Zoom-style control bar (Talk / Mute / Type / Leave).
The v1 report never saw this and treated the typed "Ask Noum" chat as the coach
relationship, recommending it be demoted from a primary destination to
contextual help. This surface shows the primary coach interaction is already a
voice call, with typed chat as the secondary "Type" affordance — so that
recommendation is arguing against an architecture the app already moved past.

**F-01 / F-02 / F-02b / F-03 — the Review → Retry teaching loop.**
The report's single strongest claim was that Review is "conceptually close,
structurally wrong," missing "What I heard / One step better / Try it now." These
captures show that loop already exists when a rep carries a rewrite snapshot:
- a verified verbatim quote from the rep ("Source: original transcript · 0:48"),
- a one-observation bounded diagnosis,
- a "One-step upgrade" card with WHAT I HEARD (the user's own words) vs a
  ONE-STEP UPGRADE rewrite with changed words highlighted and "meaning and voice
  preserved,"
- a TARGET FOR THE RETRY line, and
- a one-tap targeted retry that reopens the **same source prompt** (not a script
  of the rewrite).
The report's finding is right about the seeded rep it saw (the card only renders
when a durable rewrite snapshot exists) but wrong that the capability is missing.
The real gap is making that card reliably earned, not building it.

**F-08 / F-09 — Ask Noum working, not offline.**
The report only ever saw Ask Noum in its "temporarily unavailable" state and
judged the packaging from that. These show the bounded context card, then a real
evidence-aware coach reply landing as one usable next action.

**O-01 … O-05 — onboarding.** Welcome → context → challenge → style → summary:
the first-run flow the report flagged as unverifiable.

**P-01 / P-02 — the paywall** value hierarchy, also unverifiable in v1.

**W-01 / W-02 — the Day-7 durable first-week read**, the "believable progress
over time" pillar the report could not assess.

## Supplemental non-screenshot evidence

- `docs/CURRENT_STATE.md` (431 KB) — omitted from v1. This is the doc that would
  have kept the report from calling the league / practice-partners surfaces
  "placeholders": they are real systems behind deliberate release gates.
- `coach-arena/prompt-layer-latest.md` + `prompt-layer-failures.md` — the
  prompt-faithful eval the report **ignored**. Its gold-suite mean is currently
  **failing** its own gate (69.6 vs 70), with 21 sub-70 fixtures, a score floor
  of 22, and 4 placeholder leaks. The report cited only the rosier app-path
  average (81.16, in `app-path-latest.md`), so its read of coaching-content
  quality is more favourable than Noum's own evidence supports.

## How Deep Research should use this

Treat v1 + v2 together as the current-state evidence. Where the first report said
a capability is **missing** (the review teaching loop, the live coach call, a
working coach reply), v2 shows it already exists — so the correct framing is
"sharpen and reliably surface what is half-built," not "build what is absent."
Where the report leaned on the single most favourable eval number, read the
prompt-layer report and `failures.md` for the less flattering, more complete
picture.

## Known gaps

- The live call's real spoken audio loop can't run without a live provider and
  microphone, so L-01/L-02 use the forced deterministic caption — they prove the
  surface and its controls, not a real voice exchange.
- `20-lesson-detail` (a conditional tap inside v1's advancement tour) is still
  uncaptured; not worth re-running the 4-minute v1 tour for one screen.
